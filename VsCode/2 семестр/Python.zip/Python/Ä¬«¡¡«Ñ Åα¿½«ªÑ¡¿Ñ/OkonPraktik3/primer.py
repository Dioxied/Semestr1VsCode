import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QComboBox, QCheckBox, QSpinBox, QVBoxLayout)
from PyQt5.QtGui import QFont 
from PyQt5.QtGui import QPixmap 
from PyQt5.QtCore import Qt 
import os 


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # Установка заголовка окна
        self.setWindowTitle("Пример PyQt5 виджетов")
        # Combobox
        self.combo_box = QComboBox()
        self.combo_box.addItem("Вариант 1")
        self.combo_box.addItem("Вариант 2")
        self.combo_box.addItem("Вариант 3")
        # Checkbox
        self.check_box = QCheckBox("Выбрать")
         # Spinbox
        self.spin_box = QSpinBox()
        self.spin_box.setRange(0, 100)  # Установка диапазона значений
         # Layout
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Combobox:"))
        layout.addWidget(self.combo_box)
        layout.addWidget(QLabel("Checkbox:"))
        layout.addWidget(self.check_box)
        layout.addWidget(QLabel("Spinbox:"))
        layout.addWidget(self.spin_box)

        self.setLayout(layout)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())

