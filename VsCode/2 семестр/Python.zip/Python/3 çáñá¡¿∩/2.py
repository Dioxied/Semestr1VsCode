def fun(sp=[]):
    if len(sp) < 3:
        return sp
    if sp[-1] < sp[-2]:
        sp.remove(sp[-1])
    while True:
        if sp[-1] < sp[-2]:
            sp.remove(sp[-1])
        udal = False
        i = 2
        while i < len(sp)-1:
            if sp[i-2] < sp[i-1] > sp[i]:
                sp.remove(sp[i-1])
                i = i + 1
                udal = True
            i = i + 1
        if not udal:
            break
    sp1=[]
    for i in sp:    
        if i not in sp1:
            sp1.append(i)
    return sp1
            
spisok = [int(i) for i in input().split()]
all = []
for i in range(len(spisok)):
    for j in range(i, len(spisok)):
        pos = [spisok[i]]
        for k in range(j, len(spisok)):
            if spisok[k] > spisok[i]:
                pos.append(spisok[k])
        all.append(fun(pos))
        pos=[]
maxi = []
for i in all:
    if len(i) > len(maxi):
        maxi = i
print(maxi)
print(len(maxi))
print(*all, sep='\n')