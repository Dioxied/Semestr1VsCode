import unittest
from 3 import plus

class TestPlusFunction(unittest.TestCase):
    def setUp(self):
        self.sp = [1, '+', 2]

if __name__ == '__main__':
    unittest.main()
