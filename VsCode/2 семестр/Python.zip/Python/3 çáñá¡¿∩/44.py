def mod(a, n):
    return a%n

for a in range(10000):
    if (a )