stroka = input()

for i in range(len(stroka)):
    stroka = stroka.replace("()", '').replace("{}", '').replace("[]", '')
    if len(stroka) == 0:
        print('true')
        break
else:
    print('false')

if(stroka == "false"):
    print