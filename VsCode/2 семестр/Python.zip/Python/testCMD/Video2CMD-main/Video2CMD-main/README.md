# Video2CMD
```transform video to ASCII in the cmd```

# FFMPEG (NEEDED)
```
1. download rar from here : https://github.com/BtbN/FFmpeg-Builds/releases (or the exe here : https://cdn.discordapp.com/attachments/979083282664804483/982317967306006528/ffmpeg.exe)
2. place the /bin/ffmpeg.exe from the rar file in the tool folder
3. start and enjoy
```

# Requirements
```
type : "pip install -r requirements.txt" in the cmd
```

# Start
```
do "python main.py" in the cmd!
put the name of your MP4 file !
```
